package com.forcpacebj.api.business;

import com.forcpacebj.api.Program;
import lombok.val;
import org.sql2o.Sql2o;

public class db {

    public static Sql2o sql2o;

    static {

        val url = "jdbc:mysql://47.103.58.94:33060/{db}?useUnicode=true&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC";

        sql2o = new Sql2o(url.replace("{db}", Program.mysqlDB), "root", "159357zx/C");
    }
}
