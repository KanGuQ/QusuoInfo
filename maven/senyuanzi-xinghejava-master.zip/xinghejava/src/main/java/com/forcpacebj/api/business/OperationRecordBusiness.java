package com.forcpacebj.api.business;

/**
 * 操作记录 business
 */
public class OperationRecordBusiness {

    /**
     * 插入操作记录
     */


    // todo


}
