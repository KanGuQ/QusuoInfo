package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProjectUserInfo {

    private UserInfo user;
}
