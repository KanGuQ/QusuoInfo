package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecordPictureInfo extends BaseEntity {

    private String pictureUrl;

    private String name;
}
