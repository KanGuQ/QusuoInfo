package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProjectCooperatorInfo extends BaseEntity {

    private UserInfo user;
}
