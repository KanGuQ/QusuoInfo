package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by pc on 2019/10/9.
 */
@Setter
@Getter
public class ProductParameterInfo extends CatalogParameterInfo {

    private String parameterValue;

}
