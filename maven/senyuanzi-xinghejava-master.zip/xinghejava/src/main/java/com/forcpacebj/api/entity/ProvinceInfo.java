package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProvinceInfo extends BaseEntity {

    private String provinceId;
    private String provinceName;
}
