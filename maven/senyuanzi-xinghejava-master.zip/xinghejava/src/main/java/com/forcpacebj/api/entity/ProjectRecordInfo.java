package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProjectRecordInfo extends RecordInfo {

    private ProjectInfo project;
}
