package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductSetCategoryInfo extends TreeBase {

    private int sortNumber;
}
