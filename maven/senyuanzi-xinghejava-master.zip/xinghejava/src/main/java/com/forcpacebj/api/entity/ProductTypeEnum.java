package com.forcpacebj.api.entity;

public enum ProductTypeEnum {

    Default,

    /**
     * 投影机
     */
    Projector,

    /**
     * 幕布
     */
    Curtain

}
