package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FriendGroupInfo extends BaseEntity {

    private String groupId;

    private String groupName;
}
