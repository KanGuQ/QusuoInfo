package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PeopleRecordInfo extends RecordInfo {

    private PeopleInfo people;
}
