package com.forcpacebj.api.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecordStaticInfo extends BaseEntity {


    private int recordDay;

    private int totalCount;
}
