package com.forcpacebj.api.entity;

public enum RecordTypeEnum {

    /**
     * 日志
     */
    Record,

    /**
     * 工地纪要
     */
    WorkBrief
}
