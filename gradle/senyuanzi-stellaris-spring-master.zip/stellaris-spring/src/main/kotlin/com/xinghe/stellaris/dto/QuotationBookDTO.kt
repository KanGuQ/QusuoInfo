package com.xinghe.stellaris.dto

data class QuotationBookDTO(val quotationBookId: Long)