package com.xinghe.stellaris

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class StellarisApplication

fun main(args: Array<String>) {
    runApplication<StellarisApplication>(*args)
}
