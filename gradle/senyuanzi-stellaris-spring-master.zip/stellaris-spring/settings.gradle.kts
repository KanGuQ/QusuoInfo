rootProject.name = "stellaris"
